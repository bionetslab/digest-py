# digest-py
Python package for DIGEST

```
git clone git@github.com:bionetslab/digest-py.git
cd digest-py
git submodule init
git submodule update
cd biodigest/digest
git pull origin main
```


